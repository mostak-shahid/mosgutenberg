export const bgColors = {
	primary: '#007bff',
	secondary: '#6c757d',
};

export const colors = {
	white: '#ffffff',
};
